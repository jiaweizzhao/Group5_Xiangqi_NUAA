﻿package org.xiangqi.rule;

import org.xiangqi.main.*;


public class ArmsRule extends ChessRule {  
	
	public boolean Move(ChessPoint [][]play,int firstStepRow, int firstStepColumn, int nextStepRow, int nextStepColumn) { 
	
	
		//�����Ƿ���� 
		if(firstStepColumn>5){//û�й��� 
			if(firstStepRow!=nextStepRow) 
			{
								return false; 
			}

			else { 
				if(nextStepColumn-firstStepColumn==-1) 
					{
						return true; 
					}
				else {
					return false; 
				}
			} 
		} 
		else{//���� 
			//���� 
			if(Math.abs(firstStepRow-nextStepRow)==1&&firstStepColumn==nextStepColumn){ return true;} 
		
			//ǰ�� 
			else if(firstStepRow==nextStepRow&&nextStepColumn-firstStepColumn==-1){ return true;} 
			else {
				return false;
			} 
		} 
	} 	
	public boolean eatMove(ChessPoint[][] play, int firstStepRow, int firstStepColumn, int nextStepRow, int nextStepColumn) { 
		if(outBoard(nextStepRow,nextStepColumn)&&play[nextStepRow][nextStepColumn]!=null)
		{
			if(oppositeSign(play[firstStepRow][firstStepColumn], play[nextStepRow][nextStepColumn])&&play[nextStepRow][nextStepColumn].ifPieceExsit != false){ 
				
				return false ; 
			} 
			else
		
				return true ; 
		}
		else
			return false;
	} 
}	/* �����*/ 