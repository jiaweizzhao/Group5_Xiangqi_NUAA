﻿package org.xiangqi.rule;

import org.xiangqi.main.*;

public class CannonRule extends ChessRule{ 
	
	int hasOne = 0;   //����֮���ӵĸ����� 
	
	public boolean Move(ChessPoint [][]play,int thisStepRow, int thisStepColumn, int nextStepRow, int nextStepColumn) { 	
	
		if(thisStepRow == nextStepRow&&thisStepColumn != nextStepColumn){//������ 
			int max = thisStepColumn > nextStepColumn ? thisStepColumn : nextStepColumn; 
			int min = thisStepColumn > nextStepColumn ? nextStepColumn : thisStepColumn; 
			for(int i = min;i <= max;i++){ 
				if(i<10&&play[thisStepRow][i]!=null)
				if(play[thisStepRow][i].ifPieceExsit != false){ 
				hasOne++; 
				} 
			}
			System.out.println(hasOne);	
			if(hasOne == 1){
				
				return true ; 
			} //û����
			else if(hasOne == 3&&play[nextStepRow][nextStepColumn].ifPieceExsit != false){ //�����
				return true ; 
			} 
			else 
				return false ; 
		} 
		else if(thisStepRow != nextStepRow&&thisStepColumn == nextStepColumn){//������ 	
			int max = thisStepRow > nextStepRow ? thisStepRow : nextStepRow; 
			int min = thisStepRow > nextStepRow ? nextStepRow : thisStepRow; 
			for(int i = min;i <= max;i++){ 
				if(i<9&&play[i][thisStepColumn]!=null)
				if(play[i][thisStepColumn].ifPieceExsit != false){ 
				hasOne++; 
				} 
			} 
		
			if(hasOne == 1){ 
			return true ; 
			} 
			else if(hasOne == 3&&play[nextStepRow][nextStepColumn].ifPieceExsit != false){ 
			return true ; 
			} 
			else 
				return false ; 
		} 
		else
			return false; 
	} 
	public boolean eatMove(ChessPoint[][] play, int firstStepRow, int firstStepColumn, int nextStepRow, int nextStepColumn) { 
	
		if(hasOne == 1){//�����м����� 
			return true ; 
		} 
		else if(hasOne == 3){ 
			if(outBoard(nextStepRow,nextStepColumn)&&play[nextStepRow][nextStepColumn]!=null)
			{
				if(oppositeSign(play[firstStepRow][firstStepColumn], play[nextStepRow][nextStepColumn])&&play[nextStepRow][nextStepColumn].ifPieceExsit != false){ 
					
					return false ; 
				} 
				else
			
					return true ; 
			}
			else
				return false;
				
		} 
		else
		{
			return false ; 
		}
			
		} 
	
	} 	/** 
	* �ڹ���:�ڿ���Խ��һ����eatһ���ӵ��ǲ�����Խ�������һ�� 
	* ��ֱ��*/ 