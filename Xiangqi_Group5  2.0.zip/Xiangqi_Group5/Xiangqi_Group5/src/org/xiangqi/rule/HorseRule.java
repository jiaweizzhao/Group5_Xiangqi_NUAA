﻿package org.xiangqi.rule;

import org.xiangqi.main.*;

public class HorseRule extends ChessRule{ 
	
	public boolean Move(ChessPoint[][] play, int firstStepRow, int firstStepColumn, int nextStepRow, int nextStepColumn) { 
	
		if(Math.abs(firstStepRow-nextStepRow) == 2){//the horse ������  
		
			//������ 
			if(play[firstStepRow+1][firstStepColumn]!=null&&firstStepRow < nextStepRow&&play[firstStepRow+1][firstStepColumn].ifPieceExsit == false&&Math.abs(firstStepColumn-nextStepColumn) == 1){ 
			
				return true ; 
			} 
			else if(play[firstStepRow-1][firstStepColumn]!=null&&firstStepRow > nextStepRow&&play[firstStepRow-1][firstStepColumn].ifPieceExsit == false&&Math.abs(firstStepColumn-nextStepColumn) == 1){//������ 
			
				return true ; 
			} 
		
		} 
		else if(Math.abs(firstStepColumn-nextStepColumn) == 2){//������ 
		//������ 
			if(outBoard(firstStepRow,firstStepColumn-1)&&firstStepColumn > nextStepColumn&&play[firstStepRow][firstStepColumn-1].ifPieceExsit == false&&Math.abs(firstStepRow-nextStepRow) == 1){ 
			
			return true ; 
			} 
			else if(outBoard(firstStepRow,firstStepColumn+1)&&firstStepColumn < nextStepColumn&&play[firstStepRow][firstStepColumn+1].ifPieceExsit == false&&Math.abs(firstStepRow-nextStepRow) == 1){//������ 
			
			return true ; 
			} 
		}
		return false; 
	} 
	public boolean eatMove(ChessPoint[][] play, int firstStepRow, int firstStepColumn, int nextStepRow, int nextStepColumn) { 
	
		if(outBoard(nextStepRow,nextStepColumn)&&play[nextStepRow][nextStepColumn]!=null)
		{
			if( oppositeSign(play[firstStepRow][firstStepColumn], play[nextStepRow][nextStepColumn])&&play[nextStepRow][nextStepColumn].ifPieceExsit != false){ 
				
				return false ; 
			} 
			else
		
				return true ; 
		}
		else
			return false;
	} 
	
} 