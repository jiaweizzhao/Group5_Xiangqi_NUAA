package org.xiangqi.rule;

import org.xiangqi.main.*;

public class GeneralRule extends ChessRule{ 
	
	public boolean Move(ChessPoint[][] play, int firstStepRow, int firstStepColumn, int nextStepRow, int nextStepColumn) { 	
	if(generalIsOutBroad(nextStepRow, nextStepColumn)){ 
			if(Math.abs(firstStepRow-nextStepRow) == 1&&Math.abs(firstStepColumn-nextStepColumn) == 0){//������ 
			return true ; 
			} 
			else if(Math.abs(firstStepRow-nextStepRow) == 0&&Math.abs(firstStepColumn-nextStepColumn) == 1){ 
			return true ; 
			} 
	} 
	return false; 
	} 
	
	public boolean eatMove(ChessPoint[][] play, int firstStepRow, int firstStepColumn, int nextStepRow, int nextStepColumn) { 
		if(outBoard(nextStepRow,nextStepColumn)&&play[nextStepRow][nextStepColumn]!=null)
		{
			if(oppositeSign(play[firstStepRow][firstStepColumn], play[nextStepRow][nextStepColumn])&&play[nextStepRow][nextStepColumn].ifPieceExsit != false){ 
				
				return false ; 
			} 
			else
		
				return true ; 
		}
		else
			return false;
	} 
	
	/**�����Ƿ�Խ��*/ 
	public boolean generalIsOutBroad(int nextStepRow,int nextStepColumn){ 
		if(nextStepRow >= 4&&nextStepRow <=6&&nextStepColumn >= 8&&nextStepColumn <= 10){ 
			return true ; 
		}  
		return false ; 
	} 
} 	/** 
	* �����ƶ�����*/
	