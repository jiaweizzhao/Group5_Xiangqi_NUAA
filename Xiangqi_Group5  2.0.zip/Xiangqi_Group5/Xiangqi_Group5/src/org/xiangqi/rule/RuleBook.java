﻿package org.xiangqi.rule;

import org.xiangqi.main.*;

public class RuleBook { 

	static private ChessBoard chessPiece;

	public RuleBook (ChessBoard newChessPiece)
	{
		chessPiece = newChessPiece;
	}
	public static boolean lookupRuleBook(int presentPointX,int presentPointY,int afterPointX,int afterPointY){ 
		String chessName;
		ChessRule rule;
		chessName = chessPiece.point[presentPointX][presentPointY].getPiece().name;
		if(chessName.equals("炮")){ 
			rule = new CannonRule(); 
			return rule.canMove(chessPiece.point, presentPointX, presentPointY, afterPointX, afterPointY);
		} 
		else if(chessName.equals("車")){ 
			rule = new VehicleRule(); 
			return rule.canMove(chessPiece.point, presentPointX, presentPointY, afterPointX, afterPointY);
		} 
		else if(chessName.equals("馬")){ 
			rule = new HorseRule();
			return rule.canMove(chessPiece.point, presentPointX, presentPointY, afterPointX, afterPointY);
		} 
		else if(chessName.equals("相")){ 
			rule = new ElephantRule(); 
			return rule.canMove(chessPiece.point, presentPointX, presentPointY, afterPointX, afterPointY);
		} 
		else if(chessName.equals("仕")){ 
			System.out.print(chessName );
			rule = new ChapRule(); 
			return rule.canMove(chessPiece.point, presentPointX, presentPointY, afterPointX, afterPointY);
		} 
		else if(chessName.equals("帅")){ 
			rule = new GeneralRule(); 
			return rule.canMove(chessPiece.point, presentPointX, presentPointY, afterPointX, afterPointY);
		} 
		else if(chessName.equals("兵")){
			//System.out.print(chessName );
			rule = new ArmsRule(); 
			return rule.canMove(chessPiece.point, presentPointX, presentPointY, afterPointX, afterPointY);
		} 
		else return false; 
		} 
} 