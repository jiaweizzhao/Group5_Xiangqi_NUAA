﻿package org.xiangqi.rule;

import org.xiangqi.main.*;

public class ElephantRule extends ChessRule{ 
	
		public boolean Move(ChessPoint[][] play, int firstStepRow, int firstStepColumn, int nextStepRow, int nextStepColumn) { 
		
			if(nextStepColumn>=5){  
				if(outBoard(nextStepRow, nextStepColumn)==true&&Math.abs(firstStepRow-nextStepRow) == 2&&Math.abs(firstStepColumn-nextStepColumn) == 2&&isMove(firstStepRow,firstStepColumn,nextStepRow,nextStepColumn,play)){ 
					return true ; 
				} 
			} 
			return false; 
		} 
		public boolean eatMove(ChessPoint[][] play, int firstStepRow, int firstStepColumn, int nextStepRow, int nextStepColumn) { 
			if(outBoard(nextStepRow,nextStepColumn)&&play[nextStepRow][nextStepColumn]!=null)
			{
				if(oppositeSign(play[firstStepRow][firstStepColumn], play[nextStepRow][nextStepColumn])&&play[nextStepRow][nextStepColumn].ifPieceExsit != false){ 
					
					return false ; 
				} 
				else
			
					return true ; 
			}
			else
				return false; 
		} 	
		public boolean isMove(int firstStepRow,int firstStepColumn,int nextStepRow,int nextStepColumn, ChessPoint[][] play){ 
			if(outBoard(firstStepRow+1,firstStepColumn-1)&&play[firstStepRow+1][firstStepColumn-1]!=null&&nextStepRow > firstStepRow&&firstStepColumn > nextStepColumn&&play[firstStepRow+1][firstStepColumn-1].ifPieceExsit == false){//���Ϸ� 
				return true ; 
			} 
			else if(outBoard(firstStepRow+1,firstStepColumn+1)&&play[firstStepRow+1][firstStepColumn+1]!=null&&nextStepRow > firstStepRow&&firstStepColumn < nextStepColumn&&play[firstStepRow+1][firstStepColumn+1].ifPieceExsit == false){//���·� 
				return true ; 
			} 
			else if(outBoard(firstStepRow-1,firstStepColumn-1)&&play[firstStepRow-1][firstStepColumn-1]!=null&&nextStepRow < firstStepRow&&firstStepColumn > nextStepColumn&&play[firstStepRow-1][firstStepColumn-1].ifPieceExsit == false){//���Ϸ� 
				return true ; 
			} 
			else if(outBoard(firstStepRow-1,firstStepColumn+1)&&play[firstStepRow-1][firstStepColumn+1]!=null&&nextStepRow < firstStepRow&&firstStepColumn < nextStepColumn&&play[firstStepRow-1][firstStepColumn+1].ifPieceExsit == false){//���·� 
				return true ; 
		} 
		else return false ; 
		} 
		
	} 	/** 
	* ����ƶ�����*/ 
	
	