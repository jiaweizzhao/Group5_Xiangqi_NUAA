/**
 * 
 */
/**
 * @author jiaweizhao
 *
 */
package org.xiangqi.rule;