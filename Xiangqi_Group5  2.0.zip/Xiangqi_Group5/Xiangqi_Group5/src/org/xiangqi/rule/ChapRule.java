package org.xiangqi.rule;

import org.xiangqi.main.*;

public class ChapRule extends ChessRule{ 
	
	public boolean Move(ChessPoint[][] play, int firstStepRow, int firstStepColumn, int nextStepRow, int nextStepColumn) { 
		if(Math.abs(firstStepRow-nextStepRow) == 1&&Math.abs(firstStepColumn-nextStepColumn) == 1&&chapIsOutBroad(nextStepRow,nextStepColumn)){ 
			return true ; 
		} 
		else
			return false; 
	} 	
	public boolean eatMove(ChessPoint[][] play, int firstStepRow, int firstStepColumn, int nextStepRow, int nextStepColumn) { 
		if(nextStepRow<=9&& nextStepColumn<=10&& play[nextStepRow][nextStepColumn]!=null)
		{
			if(oppositeSign(play[firstStepRow][firstStepColumn], play[nextStepRow][nextStepColumn])&&play[nextStepRow][nextStepColumn].ifPieceExsit != false){ 
				
				return false ; 
			} 
			else
		
				return true ; 
		}
		else
			return false; 
	} 
	/**ʿ�Ƿ�Խ��*/ 
	public boolean chapIsOutBroad(int nextStepRow,int nextStepColumn){  
		if(outBoard(nextStepRow,nextStepColumn)&& nextStepRow >= 4&&nextStepRow <=6&&nextStepColumn >= 8&&nextStepColumn <= 10){ 
			return true ; 
		} 
		return false ; 
	
	} 
	
} 	/** 
* ʿ�ƶ�����*/ 
	