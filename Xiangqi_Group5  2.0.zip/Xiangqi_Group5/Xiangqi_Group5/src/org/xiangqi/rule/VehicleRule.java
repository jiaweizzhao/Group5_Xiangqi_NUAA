﻿package org.xiangqi.rule;

import org.xiangqi.main.*;

	/** 
	* ����ֱ�� */  
public class VehicleRule extends ChessRule{ 

	int hasOne = 0; //����֮���ӵĸ����� 
	
	public boolean Move(ChessPoint[][] play, int firstStepRow, int firstStepColumn, int nextStepRow, int nextStepColumn) { 
			if(firstStepRow == nextStepRow&&firstStepColumn != nextStepColumn){//������ 
				
				int max = firstStepColumn > nextStepColumn ? firstStepColumn : nextStepColumn; 
				int min = firstStepColumn > nextStepColumn ? nextStepColumn : firstStepColumn; 
				
				for(int i = min;i <= max;i++){
					if(i<=10&&play[firstStepRow][i]!=null)
					if(play[firstStepRow][i].ifPieceExsit != false){ 
					hasOne++; 
				} 
				} 
			
				if(hasOne == 1){ 
				return true ; 
				} 
				else if(hasOne == 2&&play[nextStepRow][nextStepColumn].ifPieceExsit != false){ 
				return true ; 
				} 
			} 
			else if(firstStepRow != nextStepRow&&firstStepColumn == nextStepColumn){//������ 
			
				int max = firstStepRow > nextStepRow ? firstStepRow : nextStepRow; 
				int min = firstStepRow > nextStepRow ? nextStepRow : firstStepRow; 
				
				for(int i = min;i <= max;i++){ 
					if(i<=9 && play[i][firstStepColumn]!=null)
					if(play[i][firstStepColumn].ifPieceExsit != false){ 
					hasOne++; 
					} 
				} 
			
				if(hasOne == 1){ 
				return true ; 
				} 
				else if(hasOne == 2&&play[nextStepRow][nextStepColumn].ifPieceExsit != false){ 
				return true ; 
				} 
			} 
			return false; 

	} 
	public boolean eatMove(ChessPoint[][] play, int firstStepRow, int firstStepColumn, int nextStepRow, int nextStepColumn) { 
	
		if(hasOne == 1){ 
			return true ; 
		} 
		else if(hasOne == 2){ 
			if(outBoard(nextStepRow,nextStepColumn)&&play[nextStepRow][nextStepColumn]!=null)
			{
				if(oppositeSign(play[firstStepRow][firstStepColumn], play[nextStepRow][nextStepColumn])&&play[nextStepRow][nextStepColumn].ifPieceExsit != false){ 
					
					return false ; 
				} 
				else
			
					return true ; 
			}
			else
				return false;
		}
		return false ; 
	} 

} 