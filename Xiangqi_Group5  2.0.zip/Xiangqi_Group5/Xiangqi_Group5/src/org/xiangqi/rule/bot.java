package org.xiangqi.rule;

import org.xiangqi.main.ChessBoard;

import org.xiangqi.main.ChessPoint;

public class bot {
	private ChessBoard chessPiece;
	private int hang;
	private int lie;
	private ChessRule piece;
	public bot (ChessBoard newChessPiece)
	{
		chessPiece = newChessPiece;
		hang = 100;
		lie = 100;
	}

	public String check()
	{
			int row = 100;
			int column = 100;
			//int i,j;
			boolean flag = false ;
			/*for(i=1;i<=9;i++)
			{
				for(j=1;j<=10;j++)
				{
					if(chessPiece.point[i][j].getPiece()!=null)
					{
						System.out.print(i);
						System.out.print(j);
						System.out.print(chessPiece.point[i][j].getPiece().name);
						System.out.println(chessPiece.point[i][j].getPiece().getPlayerType());
					}	
				}
			}*/
			while(!flag)
			{
				row = (int)( Math.random()*10);
				row = row % 9;
				column = (int) (Math.random()*10) ;
				column = column % 10;
				System.out.print("row "+ row);
				System.out.println("column" + column);
				if(chessPiece.point[row+1][column+1].getPiece()!=null)
				{
					//System.out.print(row+1);
					//System.out.print(column+1);
					//System.out.println(chessPiece.point[row+1][column+1].getPiece().getPlayerType());
					if (chessPiece.point[row+1][column+1].getPiece().getPlayerType() == 2) //�˴���a[][]Ϊ��������,boardΪ��������������Ӧ�Ķ�
					{
						//System.out.print("true");
						flag = true;
					}
				}
				
			}
			lie = column+1;
			hang = row+1;
			return chessPiece.point[hang][lie].getPiece().name;//�˴�Ӧ�������������괦��row,columnʱ���ӵ�����
	}
	
	public void run()
	{
		String chessName;

		int firstCounter=1,secondCounter=1;
		int preHang = 0,preLie = 0;
		boolean flag = false;
		ChessPoint temp  ;
		for(firstCounter=1;firstCounter<=5;firstCounter++)
		{
			for(secondCounter=1;secondCounter<=10;secondCounter++)
			{
				if(firstCounter==5 &&secondCounter ==6)
				{
					break;
				}
					temp = chessPiece.point[firstCounter][secondCounter];
					chessPiece.point[firstCounter][secondCounter]=chessPiece.point[10-firstCounter][11-secondCounter];
					chessPiece.point[10-firstCounter][11-secondCounter]=temp;
			}
		}
		while(!flag)
		{
			chessName = check(); 
			preHang = hang;
			preLie = lie;
			if(chessName.equals("��")){ 
				flag = CannonRun();
			} 
			else if(chessName.equals("܇")){ 
				flag = VehicleRun(); 
			} 
			else if(chessName.equals("�R")){ 
				flag = HorseRun(); 
			} 
			else if(chessName.equals("��")){ 
				flag = ElephantRun(); 
			} 
			else if(chessName.equals("��")){ 
				flag = ChapRun(); 
			} 
			else if(chessName.equals("˧")){ 
				flag = GeneralRun(); 
			} 
			else if(chessName.equals("��")){ 
				flag = ArmsRun(); 
			} 
			else {
				flag = false;
			}
		}
		if(chessPiece.point[hang][lie]!=null)
		{

			chessPiece.changePieceToPiece(preHang, preLie, hang, lie);
			System.out.printf("%d %d %d %d \n",preHang,preLie,hang,lie);
		}
		for(firstCounter=1;firstCounter<=5;firstCounter++)
		{
			for(secondCounter=1;secondCounter<=10;secondCounter++)
			{
				if(firstCounter==5 &&secondCounter ==6)
				{
					break;
				}
					temp = chessPiece.point[firstCounter][secondCounter];
					chessPiece.point[firstCounter][secondCounter]=chessPiece.point[10-firstCounter][11-secondCounter];
					chessPiece.point[10-firstCounter][11-secondCounter]=temp;
			}
		}
		
	/*	for(firstCounter=1;firstCounter<=5;firstCounter++)
		{
			for(secondCounter=1;secondCounter<=10;secondCounter++)
			{
				if(firstCounter==5 &&secondCounter ==6)
				{
					break;
				}
				if(chessPiece.point[firstCounter][secondCounter].getPiece() != null  && chessPiece.point[10-firstCounter][11-secondCounter].getPiece() != null)
				{
					temp = chessPiece.point[firstCounter][secondCounter].getPiece();
					chessPiece.point[firstCounter][secondCounter].removePiece();
					chessPiece.point[firstCounter][secondCounter].setPiece(chessPiece.point[10-firstCounter][11-secondCounter].getPiece(),chessPiece);
					chessPiece.point[10-firstCounter][11-secondCounter].setPiece(temp,chessPiece);
				}
				else if(chessPiece.point[firstCounter][secondCounter].getPiece() != null && chessPiece.point[10-firstCounter][11-secondCounter].getPiece() == null )
				{
					chessPiece.point[10-firstCounter][11-secondCounter].setPiece(chessPiece.point[firstCounter][secondCounter].getPiece(),chessPiece);
					chessPiece.point[firstCounter][secondCounter].removePiece();
				}
				else if(chessPiece.point[firstCounter][secondCounter].getPiece() == null && chessPiece.point[10-firstCounter][11-secondCounter].getPiece() != null )
				{
					chessPiece.point[firstCounter][secondCounter].setPiece(chessPiece.point[10-firstCounter][11-secondCounter].getPiece(),chessPiece);
					chessPiece.point[10-firstCounter][11-secondCounter].removePiece();
				}
			}
		}*/
	}
	
	private boolean ArmsRun()
	{
		piece = new ArmsRule(); 
		boolean flag = false;
		int nextHang,nextLie;
		int firstCounter = 0,secondCounter = 0;
		for(firstCounter = -1;firstCounter <= 1;firstCounter ++)
		{
			for(secondCounter = -1;secondCounter <= 1;secondCounter ++)
			{
				nextHang = hang + firstCounter;
				nextLie = lie + secondCounter;
				flag = piece.canMove(chessPiece.point,hang,lie,nextHang,nextLie);
				if(flag == true)
				{
					hang = nextHang;
					lie = nextLie;
					return flag;
				}
			}
		}
		return flag;
	}
	private boolean CannonRun()
	{
		piece = new CannonRule();
		boolean flag = false;
		int nextHang,nextLie;
		int firstCounter = 0,secondCounter = 0;
		for(firstCounter = -2;firstCounter <= 2;firstCounter ++)
		{
			for(secondCounter = -2;secondCounter <= 2;secondCounter ++)
			{
				nextHang = hang + firstCounter;
				nextLie = lie + secondCounter;
				flag = piece.canMove(chessPiece.point,hang,lie,nextHang,nextLie);
				if(flag == true)
				{
					hang = nextHang;
					lie = nextLie;
					return flag;
				}
			}
		}
		return flag;
	}
	
	private boolean ChapRun()
	{
		piece = new ChapRule(); 
		boolean flag = false;
		int nextHang,nextLie;
		int firstCounter = 0,secondCounter = 0;
		for(firstCounter = -1;firstCounter <= 1;firstCounter ++)
		{
			for(secondCounter = -1;secondCounter <= 1;secondCounter ++)
			{
				nextHang = hang + firstCounter;
				nextLie = lie + secondCounter;
				flag = piece.canMove(chessPiece.point,hang,lie,nextHang,nextLie);
				if(flag == true)
				{
					hang = nextHang;
					lie = nextLie;
					return flag;
				}
			}
		}
		return flag;
	}
	
	private boolean ElephantRun()
	{
		piece = new ElephantRule();
		boolean flag = false;
		int nextHang,nextLie;
		int firstCounter = 0,secondCounter = 0;
		for(firstCounter = -2;firstCounter <= 2;firstCounter ++)
		{
			for(secondCounter = -2;secondCounter <= 2;secondCounter ++)
			{
				nextHang = hang + firstCounter;
				nextLie = lie + secondCounter;
				flag = piece.canMove(chessPiece.point,hang,lie,nextHang,nextLie);
				if(flag == true)
				{
					hang = nextHang;
					lie = nextLie;
					return flag;
				}
			}
		}
		return flag;
	}
	
	private boolean GeneralRun()
	{
		piece = new GeneralRule(); 
		boolean flag = false;
		int nextHang,nextLie;
		int firstCounter = 0,secondCounter = 0;
		for(firstCounter = -1;firstCounter <= 1;firstCounter ++)
		{
			for(secondCounter = -1;secondCounter <= 1;secondCounter ++)
			{
				nextHang = hang + firstCounter;
				nextLie = lie + secondCounter;
				flag = piece.canMove(chessPiece.point,hang,lie,nextHang,nextLie);
				if(flag == true)
				{
					hang = nextHang;
					lie = nextLie;
					return flag;
				}
			}
		}
		return flag;
	}
	
	private boolean HorseRun()
	{ 
		piece = new HorseRule();
		boolean flag = false;
		int nextHang,nextLie;
		int firstCounter = 0,secondCounter = 0;
		for(firstCounter = -2;firstCounter <= 2;firstCounter ++)
		{
			for(secondCounter = -2;secondCounter <= 2;secondCounter ++)
			{
				nextHang = hang + firstCounter;
				nextLie = lie + secondCounter;
				flag = piece.canMove(chessPiece.point,hang,lie,nextHang,nextLie);
				if(flag == true)
				{
					hang = nextHang;
					lie = nextLie;
					return flag;
				}
			}
		}
		return flag;
	}
	
	private boolean VehicleRun()
	{
		piece = new VehicleRule(); 
		boolean flag = false;
		int nextHang,nextLie;
		int firstCounter = 0,secondCounter = 0;
		for(firstCounter = -1;firstCounter <= 1;firstCounter ++)
		{
			for(secondCounter = -1;secondCounter <= 1;secondCounter ++)
			{
				nextHang = hang + firstCounter;
				nextLie = lie + secondCounter;
				flag = piece.canMove(chessPiece.point,hang,lie,nextHang,nextLie);
				System.out.println(flag);
				if(flag == true)
				{
					hang = nextHang;
					lie = nextLie;
					return flag;
				}
			}
		}
		return flag;
	}
}
