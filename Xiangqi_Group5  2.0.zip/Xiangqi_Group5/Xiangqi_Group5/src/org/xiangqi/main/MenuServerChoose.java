package org.xiangqi.main;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Spring;

import NetSocket.Server;

public class MenuServerChoose extends JFrame 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel panelServerChoose,panelEstablish,panelEnter;
	private JButton buttonEstablish,buttonEnter;
	private JLabel labelChoose,labelIP;
	private JTextField IPtext;
	private Server server;
	
	public MenuServerChoose(Server server) 
	{
		this.server = server;
		panelServerChoose = new JPanel();
    	buttonEstablish = new JButton("Estabilsh a server/New game");
    	buttonEnter = new JButton("Enter the server/Join the game");
    	labelChoose = new JLabel("Choose server mode");
    	labelChoose.setFont(new Font("Arial",0,24));
    	panelServerChoose.add("North",labelChoose);
    	panelServerChoose.add("Southwest",buttonEnter);
    	panelServerChoose.add("Southeast",buttonEstablish);
    	
    	this.add("Center",panelServerChoose);
    	this.setBackground(Color.getHSBColor(143,166,34));
    	this.setSize(400, 200);
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	this.setVisible(true);
    	this.setTitle("Choose server mode");
    	setLocationRelativeTo(getOwner()); 
  //  	panelEstablish.add("Center",labelIP);
    	System.out.print("a");
    	IPtext = new JTextField(20);
    	System.out.print("a");
    	
    	buttonEnter.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				System.out.print("a");
				String str=e.getActionCommand();
	    		if("Enter the server/Join the game".equals(str))
	    		{
	    			System.out.print("a");
	    			
	    			boolean flag = false;
	    			if(flag == false)
	    			{
	    				//System.out.print("a");
	    				 
   	    				String ip = JOptionPane.showInputDialog(IPtext,"Please enter an IP");
   	    				System.out.println("用户输入ip" + ip);
   	    				server.jionRoom(ip);
   	    				XiangqiMainFrame xiangqiMainFrame = new XiangqiMainFrame(server);
	    				flag = true;
	    			}	
	    		}
			}
		});
    	
    	
    	buttonEstablish.addActionListener(new ActionListener() 
   		{
   			public void actionPerformed(ActionEvent e) 
   			{
   				String str=e.getActionCommand();
   	    		if("Estabilsh a server/New game".equals(str))
   	    		{
   	    			boolean flag = false;
   	    			if(flag == false)
   	    			{
   	    				
						String ip = server.setRoom();
						labelIP = new JLabel();
						labelIP.setText(ip);
						JOptionPane.showMessageDialog(labelIP, "服务器ip是" + ip);
						panelServerChoose.setVisible(false);
						XiangqiMainFrame xiangqiMainFrame = new XiangqiMainFrame(server);
						dispose();
	    				flag = true;
	    				
   	    			}	
   	    		}
   			}
   		});
    }//锟斤拷始锟斤拷一锟斤拷锟斤拷锟斤拷锟斤拷  锟斤拷锟斤拷一锟斤拷锟侥癸拷锟届函锟斤拷锟斤拷锟斤拷

 
 //   private void setTitle(String string) 
    {
		// TODO Auto-generated method stub
		
	}


//	private void setDefaultCloseOperation(int exitOnClose) 
	{
		// TODO Auto-generated method stub
		
	}
 
	
	
    public void ServerEstablish() 
    {
    	 
    	 
    	
	}//锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷选锟斤拷  目前锟斤拷锟斤拷只锟角凤拷锟截达拷锟斤拷锟缴癸拷  锟斤拷锟斤拷要锟斤拷臃锟斤拷锟斤拷锟斤拷锟斤拷锟�  只锟角革拷锟竭凤拷锟斤拷锟斤拷锟窖达拷锟斤拷  锟斤拷锟皆硷拷一锟斤拷锟斤拷锟截★拷锟饺达拷锟斤拷锟诫”

    public void ServerEnter() 
    {
    	
    	
    	
	}//锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟窖★拷锟�  同锟斤拷 锟斤拷锟街伙拷歉锟斤拷叻锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟较�  锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟窖★拷锟斤拷锟斤拷锟斤拷锟斤拷选锟斤拷  锟斤拷锟皆硷拷一锟斤拷锟斤拷锟斤拷 锟斤拷锟睫凤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
   
  /*  public void actionPerformed(ActionEvent e)
	   {
	    	Object actionObject = e.getSource();
			if (actionObject == buttonEnter)
			{
				panelEnter.setVisible(false);
				ServerEnter();
			}
			else if (actionObject == buttonEstablish)     
			{
				panelEstablish.setVisible(false);
				ServerEstablish();
			}
			
	   }
	
	
*/


//	public static void main(String[] args) 
//    {
//		// TODO Auto-generated method stub
//		
//		new MenuServerChoose();
//		
//	}
	

}
