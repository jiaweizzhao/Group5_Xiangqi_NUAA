package org.xiangqi.main;

import javax.swing.*;

import java.awt.*;  
import java.awt.event.*;  

public class ChessPoint{

    public int x,y;

    public boolean ifPieceExsit;

    public ChessPiece piece = null;

    public ChessBoard board = null;
    
    public BlankPiece blank;
    
    
    public ChessPoint(int x,int y,boolean ifPieceExsit,BlankPiece blank,int w,int h){
        this.x = x;

        this.y = y;
        
        this.blank = blank;
        
        blank.setBounds(x - w / 2, y - h / 2, w, h);

        this.ifPieceExsit = ifPieceExsit;
      
    }
    
    public void setPiece(ChessPiece piece, ChessBoard board){//把相关的图片位置变换也放到这两个函数中
        this.piece = piece;

        this.board = board;

        board.add(piece);//注意一个 将棋子label加入到panel中

        int w = (board.boardWidth); 

        int h = (board.boardHeight); 

        piece.setBounds(x - w / 2, y - h / 2, w, h);//棋子的位置

        ifPieceExsit = true;
        blank.setVisible(false);

        board.validate();
    }
    
    public void removePiece(){//删除某个棋子

        if(ifPieceExsit){

            board.remove(piece);//注意  将棋子label从panel中删除掉

            ifPieceExsit = false;
            blank.setVisible(true);

            board.validate();
        }

    }
    

    public void setifPieceExsit(boolean ifPieceExsit){
        this.ifPieceExsit = ifPieceExsit;
    }


    public int getX(){
        return x;
    }
    
    public int getY(){
        return y;
    }

    public ChessPiece getPiece(){
        return piece;
    }


}