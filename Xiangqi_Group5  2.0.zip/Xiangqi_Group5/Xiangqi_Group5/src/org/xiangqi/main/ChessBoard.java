﻿package org.xiangqi.main;


import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;  
import java.io.*;  
import java.util.LinkedList; 
import org.xiangqi.rule.*;
import NetSocket.*;

public class ChessBoard extends JPanel implements MouseListener, MouseMotionListener{

    Server server = null;//服务器包里的类，待定；//构造的时候直接传已经构造好的 可以分两种构造方式一种包含服务器 即联机  一种不包含 即单机  然后再执行判断的时候分别分sever 是否等于NULL 来使用不同的方式进行移动
    
    public ChessPoint point[][];
    
    public ChessPoint convertPoint[][];
    
    public BlankPiece blank[][];

    public int boardWidth, boardHeight; 

    private int lengthX, lengthY;//x,y的长度

    private Image img;

    public Image pieceImg;

    private boolean move = false;

    int startX,startY;

    int startI, startJ;

    int startFirstX,startFirstY;
    
    bot chessBot;

    ChessPiece pieceMove;

    RuleBook ruleBook;

    ChessPiece che11,che12,ma11,ma12,pao11,pao12,xiang11,xiang12,shi11,shi12,shuai11,bing11,bing12,bing13,bing14,bing15;//先不分具体兵和将的性质

    ChessPiece che21,che22,ma21,ma22,pao21,pao22,xiang21,xiang22,shi21,shi22,shuai21,bing21,bing22,bing23,bing24,bing25;

    public ChessBoard(int width, int height, int axisX, int axisY, Server server){
    	
    	chessBot = new bot(this);
    	
    	this.server = server;
    	
        setLayout(null);

        addMouseListener(this);

        addMouseMotionListener(this);

        Color bc = getBackground();

        boardWidth = width;  

        boardHeight = height;  

        lengthX = axisX;

        lengthY = axisY;
        
        point = new ChessPoint[axisX+1][axisY+1];
        
        convertPoint = new ChessPoint[axisX+1][axisY+1];
        
        
        blank = new BlankPiece[axisX+1][axisY+1];
        
      
        
        
        for (int i = 1; i <= lengthX; i++) {  
            for (int j = 1; j <= lengthY; j++) {  
                blank[i][j] = new BlankPiece(width - 4,height - 4,this);
            }  
        }
        
        for (int i = 1; i <= lengthX; i++) {  
            for (int j = 1; j <= lengthY; j++) {  
                point[i][j] = new ChessPoint(i * boardWidth, j * boardHeight, false,blank[i][j],boardWidth,boardHeight);  
            }  
        }
        
        //etConvertPoint
        for(int i=1;i<=lengthX;i++){
   		 for(int j=1;j<=lengthY;j++){
   			 convertPoint[i][j] = point[lengthX - i + 1][lengthY - j + 1];
   		 }
   	 }
       

        ruleBook = new RuleBook(this); //rule的初始化  现在还不确定名字

        pieceImg = Toolkit.getDefaultToolkit().getImage("Piece.gif");//  棋子的图片  现在还不确定
        
        //blankPiece = new ChessPiece("車",1,1,Color.red, bc, width - 4, height - 4, this); 

        che11 = new ChessPiece("車",1,1,Color.red, bc, width - 4, height - 4, this);

        che12 = new ChessPiece("車",1,1,Color.red, bc, width - 4, height - 4, this);

        che21 = new ChessPiece("車",1,2,Color.black, bc, width - 4, height - 4, this);

        che22 = new ChessPiece("車",1,2,Color.black, bc, width - 4, height - 4, this);

        ma11 = new ChessPiece("馬",2,1,Color.red, bc, width - 4, height - 4, this);

        ma12 = new ChessPiece("馬",2,1,Color.red, bc, width - 4, height - 4, this);

        ma21 = new ChessPiece("馬",2,2,Color.black, bc, width - 4, height - 4, this);

        ma22 = new ChessPiece("馬",2,2,Color.black, bc, width - 4, height - 4, this);

        pao11 = new ChessPiece("炮",3,1,Color.red, bc, width - 4, height - 4, this);

        pao12 = new ChessPiece("炮",3,1,Color.red, bc, width - 4, height - 4, this);

        pao21 = new ChessPiece("炮",3,2,Color.black, bc, width - 4, height - 4, this);

        pao22 = new ChessPiece("炮",3,2,Color.black, bc, width - 4, height - 4, this);

        xiang11 = new ChessPiece("相",4,1,Color.red, bc, width - 4, height - 4, this);

        xiang12 = new ChessPiece("相",4,1,Color.red, bc, width - 4, height - 4, this);

        xiang21 = new ChessPiece("相",4,2,Color.black, bc, width - 4, height - 4, this);

        xiang22 = new ChessPiece("相",4,2,Color.black, bc, width - 4, height - 4, this);

        shi11 = new ChessPiece("仕",5,1,Color.red, bc, width - 4, height - 4, this);

        shi12 = new ChessPiece("仕",5,1,Color.red, bc, width - 4, height - 4, this);

        shi21 = new ChessPiece("仕",5,2,Color.black, bc, width - 4, height - 4, this);

        shi22 = new ChessPiece("仕",5,2,Color.black, bc, width - 4, height - 4, this);

        shuai11 = new ChessPiece("帅",6,1,Color.red, bc, width - 4, height - 4, this);

        shuai21 = new ChessPiece("帅",6,2,Color.black, bc, width - 4, height - 4, this);

        bing11 = new ChessPiece("兵",7,1,Color.red, bc, width - 4, height - 4, this);

        bing12 = new ChessPiece("兵",7,1,Color.red, bc, width - 4, height - 4, this);

        bing13 = new ChessPiece("兵",7,1,Color.red, bc, width - 4, height - 4, this);

        bing14 = new ChessPiece("兵",7,1,Color.red, bc, width - 4, height - 4, this);

        bing15 = new ChessPiece("兵",7,1,Color.red, bc, width - 4, height - 4, this);

        bing21 = new ChessPiece("兵",7,2,Color.black, bc, width - 4, height - 4, this);

        bing22 = new ChessPiece("兵",7,2,Color.black, bc, width - 4, height - 4, this);

        bing23 = new ChessPiece("兵",7,2,Color.black, bc, width - 4, height - 4, this);

        bing24 = new ChessPiece("兵",7,2,Color.black, bc, width - 4, height - 4, this);

        bing25 = new ChessPiece("兵",7,2,Color.black, bc, width - 4, height - 4, this);



        //初始化Point  

        point[1][10].setPiece(che11, this);  
        point[2][10].setPiece(ma11, this);  
        point[3][10].setPiece(xiang11, this);  
        point[4][10].setPiece(shi11, this);  
        point[5][10].setPiece(shuai11, this);  
        point[6][10].setPiece(shi12, this);  
        point[7][10].setPiece(xiang12, this);  
        point[8][10].setPiece(ma12, this);  
        point[9][10].setPiece(che12, this);  
        point[2][8].setPiece(pao11, this);  
        point[8][8].setPiece(pao12, this);  
        point[1][7].setPiece(bing11, this);  
        point[3][7].setPiece(bing12, this);  
        point[5][7].setPiece(bing13, this);  
        point[7][7].setPiece(bing14, this);  
        point[9][7].setPiece(bing15, this);  
  
        point[1][1].setPiece(che21, this);  
        point[2][1].setPiece(ma21, this);  
        point[3][1].setPiece(xiang21, this);  
        point[4][1].setPiece(shi21, this);  
        point[5][1].setPiece(shuai21, this);  
        point[6][1].setPiece(shi22, this);  
        point[7][1].setPiece(xiang22, this);  
        point[8][1].setPiece(ma22, this);  
        point[9][1].setPiece(che22, this);  
        point[2][3].setPiece(pao21, this);  
        point[8][3].setPiece(pao22, this);  
        point[1][4].setPiece(bing21, this);  
        point[3][4].setPiece(bing22, this);  
        point[5][4].setPiece(bing23, this);  
        point[7][4].setPiece(bing24, this);  
        point[9][4].setPiece(bing25, this); 

    }
    
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        
        //先不放图像了  图像设置在原来的备份中

        //画线
        for (int j = 1; j <= lengthY; j++) {  
            g.drawLine(point[1][j].x, point[1][j].y, point[lengthX][j].x, point[lengthX][j].y);  
        }   

        for (int i = 1; i <= lengthX; i++) {  
            if (i != 1 && i != lengthX) {  
                g.drawLine(point[i][1].x, point[i][1].y, point[i][lengthY - 5].x,point[i][lengthY - 5].y);  
                g.drawLine(point[i][lengthY - 4].x, point[i][lengthY - 4].y,point[i][lengthY].x, point[i][lengthY].y);  
            } else {  
                g.drawLine(point[i][1].x, point[i][1].y, point[i][lengthY].x,point[i][lengthY].y);  
            }  
        } 

        g.drawLine(point[4][1].x, point[4][1].y, point[6][3].x, point[6][3].y); 

        g.drawLine(point[6][1].x, point[6][1].y, point[4][3].x, point[4][3].y);  

        g.drawLine(point[4][8].x, point[4][8].y, point[6][lengthY].x,point[6][lengthY].y);  

        g.drawLine(point[4][lengthY].x, point[4][lengthY].y, point[6][8].x,point[6][8].y); 

        for (int i = 1; i <= lengthX; i++) {  
            g.drawString("" + i, i * boardWidth, boardHeight / 2);  
        }  

        int j = 1;  

        for (char c = 'A'; c <= 'J'; c++) {  
            g.drawString("" + c, boardWidth / 4, j * boardHeight);  
            j++;  
        } 
    }
    
    //底下就是鼠标处理步骤    分sever是否为NULL分别处理
    
    public void mouseClicked(MouseEvent e){

        ChessPiece piece = null; 

        Rectangle rect = null; 
        
        BlankPiece blank = null;
        
        int boardX = e.getX();
        
        int boardY = e.getY();
        
        boolean ifHavePoint = false;
        
        

        if (e.getSource() instanceof ChessPiece) {  
            piece = (ChessPiece) e.getSource();  
            e = SwingUtilities.convertMouseEvent(piece, e, this);
            startX = piece.getBounds().x;  
            startY = piece.getBounds().y;  
  
            rect = piece.getBounds();  
            
            //e = SwingUtilities.convertMouseEvent(piece, e, this);

            for (int i = 1; i <= lengthX; i++) {  
                for (int j = 1; j <= lengthY; j++) {  
                    int x = point[i][j].getX();  
                    int y = point[i][j].getY();  
                    if (rect.contains(x, y)) {   //这样就确定了这个是哪个点了
                        startI = i; 

                        startJ = j;  

                        pieceMove = point[i][j].piece;
                        
                        ifHavePoint = true;

                        break;  
                    }  

                }  
            }
        }
        else if(e.getSource() instanceof BlankPiece && move){
        	blank = (BlankPiece) e.getSource();  
            e = SwingUtilities.convertMouseEvent(blank, e, this);
            startX = blank.getBounds().x;  
            startY = blank.getBounds().y;
            
            rect = blank.getBounds();
            
            for (int i = 1; i <= lengthX; i++) {  
                for (int j = 1; j <= lengthY; j++) {  
                    int x = point[i][j].getX();  
                    int y = point[i][j].getY();  
                    if (rect.contains(x, y)) {   //这样就确定了这个是哪个点了
                    	
                        startI = i; 

                        startJ = j;  
                        
                        ifHavePoint = true;

                        break;  
                    }  

                }
            }
            
        }
        else{
        	assert false ;
        }
        System.out.printf("%d  %d  ",startI, startJ );
        if(ifHavePoint){
        	if(move == false){//说明是第一次  
                startFirstX = startI;

                startFirstY = startJ;

                move = true;

            }
            else{//第二次  要进行判断了
                if(ruleBook.lookupRuleBook(startFirstX,startFirstY,startI,startJ)){//执行的那个判断规则函数  pieceMove startFirstX startFirstY  startI  startJ{//说明走步正确
                	
                	changePieceToPiece(startFirstX,startFirstY,startI,startJ);

                    if(server != null){//如果为多人游戏
                        multiplayerHandle();
                    }
                    else{//为单人游戏
                        aloneHandle();
                    }
                	move = false;
                }
                else{//规则不通过
                    move = false;
                }
            }
        }

    }

    public void aloneHandle(){
    	chessBot.run();
    }

    public void multiplayerHandle(){
    	server.transferPoint(pieceMove.pieceType, startFirstX, startFirstY, startI, startJ);

    }
    
    public void changePieceToPiece(int presentX,int presentY,int afterX,int afterY){
    	ChessPiece tempPiece;
    	
    	tempPiece =  point[presentX][presentY].getPiece();
    	
    	point[afterX][afterY].removePiece();
    	
    	point[presentX][presentY].removePiece();

        point[afterX][afterY].setPiece(tempPiece,this);

    }
    
    public void changeConvertPieceToConvertPiece(int presentX,int presentY,int afterX,int afterY){
    	ChessPiece tempPiece;
    	
    	tempPiece =  convertPoint[presentX][presentY].getPiece();
    	
    	convertPoint[afterX][afterY].removePiece();
    	
    	convertPoint[presentX][presentY].removePiece();

    	convertPoint[afterX][afterY].setPiece(tempPiece,this);

    }
    
    public int getPointFromConvertPointX(int x,int y){
    	return lengthX - x + 1 ;
    	
    }
    
   public int getPointFromConvertPointY(int x,int y){
	   return lengthY - y + 1;
   }
	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}