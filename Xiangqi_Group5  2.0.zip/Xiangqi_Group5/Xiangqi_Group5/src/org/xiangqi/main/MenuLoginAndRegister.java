﻿package org.xiangqi.main;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import NetSocket.*; 
public class MenuLoginAndRegister extends JFrame implements ActionListener 
{
	Server server;//服务器包里的类；
    ChessBoard board;
	private JPanel panelMain,panelCenter,panelSouth,panelNorth;
	private JButton buttonConfirm,buttonCancel,buttonRegister,buttonLogin;
	private JLabel jLabelUsername,jLabelPassword,labelWelcome,imgLabel;
	private JPasswordField passwordField;
	private JTextField usernameField;
	
    public MenuLoginAndRegister() 
    {
    	server = new Server();
    	panelMain = new JPanel();
    	buttonRegister = new JButton("Register");
    	buttonLogin = new JButton("Login");
    	labelWelcome = new JLabel("Welcome To The Chinese Chess Game!");
    	labelWelcome.setFont(new Font("Arial",2, 24));
    	labelWelcome.setBounds(20, 20,150, 50);
    	panelMain.add("Middle",labelWelcome);
    	panelMain.add(buttonLogin);
    	panelMain.add(buttonRegister);
    	panelMain.setOpaque(false);
    	this.add("Center",panelMain);
    	
    	ImageIcon background = new ImageIcon("background.png");//背景图片
    	imgLabel = new JLabel(background);//把背景图片显示在一个标签里面//把标签的大小位置设置为图片刚好填充整个面板
    	imgLabel.setBounds(0,0,background.getIconWidth(),background.getIconHeight());//把内容窗格转化为JPanel，否则不能用方法setOpaque()来使内容窗格透明
    	((JComponent) this.getContentPane()).setOpaque(false);
    	this.getLayeredPane().setLayout(null);//把背景图片添加到分层窗格的最底层作为背景
    	this.getLayeredPane().add(imgLabel,new Integer(Integer.MIN_VALUE));
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	this.setSize(background.getIconWidth(),background.getIconHeight());
    	
    	this.setResizable(false);
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setTitle("Welcome to Chinese chess");
		setLocationRelativeTo(getOwner()); 
    	
    	buttonLogin.addActionListener(new ActionListener() 
    	{
			public void actionPerformed(ActionEvent e) 
    		{
    			String str=e.getActionCommand();
	    		if("Login".equals(str))
	    		{
	    			boolean flag = false;
	    			if(flag == false)
	    			{
	    				panelMain.setVisible(false);
	    				login();
	    				flag = true;
	    			}
	    		}
    		}

			private void setVisible(boolean b) {
				// TODO Auto-generated method stub
				
			}
    	});
    	
    	buttonRegister.addActionListener(new ActionListener() 
    	{
			public void actionPerformed(ActionEvent e) {
				String str = e.getActionCommand();
				if ("Register".equals(str)) {
					boolean flag = false;
					if (flag == false) {
						panelMain.setVisible(false);
						register();
						flag = true;
					}

				}
    	}
			
			private void setVisible(boolean b) 
			{
				// TODO Auto-generated method stub
				
			}
    	
    	});//初始化一下这个面板  包含一定的构造函数参数
    }
    
    private void login() 
    {
    	usernameField = new JTextField(20);
    	passwordField = new JPasswordField(20);
    	jLabelUsername = new JLabel("Username");
    	jLabelPassword = new JLabel("Password");
    	buttonConfirm = new JButton("Confirm");
    	buttonCancel = new JButton("Cancel");
    	panelCenter = new JPanel();
    	panelSouth = new JPanel();
    	panelNorth = new JPanel();
    	       //设置布局
    	this.setLayout(new GridLayout(6,2));
    	     
    	panelNorth.add("West",jLabelUsername); 
    	panelNorth.add("East",usernameField);//第一块面板添加用户名和文本框 
    	panelNorth.setOpaque(false);
    	panelCenter.add("West",jLabelPassword);
		panelCenter.add("East",passwordField);//第二块面板添加密码和密码输入框
		panelCenter.setOpaque(false);
    	panelSouth.add("West",buttonConfirm);
    	panelSouth.add("East",buttonCancel);
    	panelSouth.setLayout(new FlowLayout());
    	panelSouth.setOpaque(false);//因为JPanel默认布局方式为FlowLayout，所以可以注销这段代码.
    	this.add("North",panelNorth);
    	this.add("Center",panelCenter);
    	this.add("South",panelSouth);
    	this.setSize(480, 800);
    	this.setResizable(false);
    	  //将三块面板添加到登陆框上面
    	 //设置显示
    	jLabelPassword.setFont(new Font("Arial", 2,24));
    	jLabelUsername.setFont(new Font("Arial", 2,24));

    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	this.setVisible(true);
    	this.setTitle("Login");
    	buttonConfirm.addActionListener(new ActionListener() 
    	{
			public void actionPerformed(ActionEvent e) 
    		{
    			String str=e.getActionCommand();
	    		if("Confirm".equals(str))
	    		{
	    			String getName = usernameField.getText();
	    			char[] getPassword = passwordField.getPassword();
	    			String newPassword = new String(getPassword); 
	    			JOptionPane.showConfirmDialog(null, "Your name is"+getName);
	    			setVisible(false);
	    			if(Server.loginIfRight(getName,newPassword)==true)
	    			{
	    				new MenuMain(server);
	    			}
	    			else
	    			{
	    				JOptionPane.showMessageDialog(null,"Name or password wrong",null, JOptionPane.INFORMATION_MESSAGE, null);
	    			}
	    		}
	    		
    		}

			private void setTitle(String string) {
				// TODO 自动生成的方法存根
				
			}
    	});
    	
    	buttonCancel.addActionListener(new ActionListener() 
    	{
			public void actionPerformed(ActionEvent e) 
    		{
    			String str=e.getActionCommand();
	    		if("Cancel".equals(str))
	    		{
	    			this.dispose();
	    		}
    		}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
    	});
    }
	//登录相应   可能还会要一个输入账号和密码面板  看能否共存于这个面板中

    private void register() 
    {
    	usernameField = new JTextField(20);
    	passwordField = new JPasswordField(20);
    	jLabelUsername = new JLabel("Username");
    	jLabelPassword = new JLabel("Password");
    	buttonConfirm = new JButton("Confirm");
    	buttonCancel = new JButton("Cancel");
    	panelCenter = new JPanel();
    	panelSouth = new JPanel();
    	panelNorth = new JPanel();
    	       //设置布局
    	this.setLayout(new GridLayout(6,2));
    	     
    	panelNorth.add("West",jLabelUsername); 
    	panelNorth.add("East",usernameField);//第一块面板添加用户名和文本框 
    	panelNorth.setOpaque(false);
    	panelCenter.add("West",jLabelPassword);
		panelCenter.add("East",passwordField);//第二块面板添加密码和密码输入框
		panelCenter.setOpaque(false);
    	panelSouth.add("West",buttonConfirm);
    	panelSouth.add("East",buttonCancel);
    	panelSouth.setOpaque(false);
    	panelSouth.setLayout(new FlowLayout());
    	this.add("North",panelNorth);
    	this.add("Center",panelCenter);
    	this.add("South",panelSouth);  //将三块面板添加到登陆框上面
    	 //设置显示
    	this.setSize(480, 800);
    	jLabelPassword.setFont(new Font("Arial", 2,24));
    	jLabelUsername.setFont(new Font("Arial", 2,24));

    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	this.setVisible(true);
    	this.setTitle("Register");
    	buttonConfirm.addActionListener(new ActionListener() 
    	{
			public void actionPerformed(ActionEvent e) 
    		{
    			String str=e.getActionCommand();
	    		if("Confirm".equals(str))
	    		{
	    			String getName = usernameField.getText();
	    			char[] getPassword = passwordField.getPassword();
	    			String newPassword = new String(getPassword); 
	    			
	    			JOptionPane.showConfirmDialog(null, "Your name is"+getName);
	    			setVisible(false);
	    			if(Server.registerSave(getName,newPassword)==true)
	    			{
	    				XiangqiMainFrame xiangqiMainFrame = new XiangqiMainFrame(server);
	    				new MenuMain(server);
	    			}
	    			else
	    			{
	    				JOptionPane.showMessageDialog(null,"Name or password wrong",null, JOptionPane.INFORMATION_MESSAGE, null);
	    			}
	    		}	    		
    		}
    	});
    	
    	buttonCancel.addActionListener(new ActionListener() 
    	{
			public void actionPerformed(ActionEvent e) 
    		{
    			String str=e.getActionCommand();
	    		if("Cancel".equals(str))
	    		{
	    			
	    		}
    		}

			private void setvisible(boolean b) {
				// TODO Auto-generated method stub
				
			}
    	});
    	
    }
    
   public void actionPerformed(ActionEvent e)
   {
    	Object actionObject = e.getSource();
		if (actionObject == buttonLogin)
		{
			this.setVisible(false);
			login();
		}
		else if (actionObject == buttonRegister)     
		{
			dispose();
			register();
		}
		else if(actionObject == "Cancel")
		{
			
			this.dispose();
		}
   }
		

	private void print(String string) {
	// TODO Auto-generated method stub
	
}


	public static void main(String[] args) 
    {
		// TODO Auto-generated method stub
		new MenuLoginAndRegister();
		
	}

	
}
