﻿package org.xiangqi.main;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField; 
import javax.swing.JTextField;

import NetSocket.Server;

public class  MenuMain extends JFrame 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel panelMain;
	private JButton buttonOnePlayer,buttonTwoPlayer;
	private JLabel labelChoose;
	private Server server;
	
    public MenuMain(Server server) 
    {
    	panelMain = new JPanel();
    	this.server = server;
    	buttonOnePlayer = new JButton("One-Player Mode");
    	buttonOnePlayer.setBounds(80, 200, 200, 80);
    	buttonTwoPlayer = new JButton("Two-Player Mode");
    	buttonTwoPlayer.setBounds(300, 200, 200, 80);
    	labelChoose = new JLabel("Choose game mode");
    	labelChoose.setFont(new Font("Arial",0,24));
    	labelChoose.setBounds(200,0,250, 250);
    	panelMain.add("North",labelChoose);
    	panelMain.add("Center",buttonTwoPlayer);
    	panelMain.add("South",buttonOnePlayer);
    //	panelMain.setBackground(Color.getHSBColor(143,166,34));
    	panelMain.setLayout(null);
    	this.add("Center",panelMain);
    	this.setSize(600, 600);
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	this.setVisible(true);
    	this.setTitle("Choose game mode");
    	setLocationRelativeTo(getOwner()); 
    	
    	buttonOnePlayer.addActionListener(new ActionListener() 
    	{
    		public void actionPerformed(ActionEvent e) 
    		{
    			String str=e.getActionCommand();
        		if("One-Player Mode".equals(str))
        		{
        			boolean flag = false;
        			if(flag == false)
        			{
        					panelMain.setVisible(false);
        				    XiangqiMainFrame xiangqiMainFrame = new XiangqiMainFrame(null);
        					flag = true;
        					
        			}
        		}
    		}
    	});

    	
    	
    	buttonTwoPlayer.addActionListener(new ActionListener() 
    	{
    		public void actionPerformed(ActionEvent e) 
    		{
    			String str=e.getActionCommand();
        		if("Two-Player Mode".equals(str))
        		{
        			boolean flag = false;
        			if(flag == false)
        			{
        					panelMain.setVisible(false);
        					flag = true;
        					if(flag)
        					{
        						new MenuServerChoose(server);
        					}
        			}	
        		}
    		}
    	});
    }//閿熸枻鎷峰閿熸枻鎷蜂竴閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹  閿熸枻鎷烽敓鏂ゆ嫹涓�閿熸枻鎷烽敓渚ョ櫢鎷烽敓灞婂嚱閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷�

   
  //  private void setTitle(String string) 
    {
		// TODO Auto-generated method stub
		
	}


//	private void setDefaultCloseOperation(int exitOnClose) 
	{
		// TODO Auto-generated method stub
		
	}

	private void aloneGame() 
	{
		
		// TODO Auto-generated method stub
		
	}
    
	private void multiplayerGame() 
	{
	
	//閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熻緝鍑ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸帴锟�
	
	
	}


	

}
