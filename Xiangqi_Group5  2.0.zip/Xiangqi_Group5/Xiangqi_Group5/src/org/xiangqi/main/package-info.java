/**
 * 
 */
/**
 * @author jiaweizhao
 *
 */
package org.xiangqi.main;