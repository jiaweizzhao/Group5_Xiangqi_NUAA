package org.xiangqi.main;

import javax.swing.*;

import java.awt.*;  
import java.awt.event.*;  

public class ChessPiece extends JLabel{

    public String name;

    public int pieceType;

    public Color backcolor,forecolor;

    public int playerType;

    public ChessBoard board;

    public int width,height;
    
    public ChessPiece(String name,int pieceType,int playerType,Color fc,Color bc,int width, int height,ChessBoard board){

        this.name = name;

        this.pieceType = pieceType;

        this.playerType = playerType;

        this.board = board;

        forecolor = fc;

        backcolor = bc;

        this.width = width;

        this.height = height;

        setSize(width, height);  

        setBackground(bc);  

        addMouseMotionListener(board);  

        addMouseListener(board);

    }
    
    public void paint(Graphics g){ //QQQ不太确定所需要提供的图片的具体样式  因为这里也有图片的裁剪问题
        g.drawImage(board.pieceImg, 2, 2, width-2, height-2, null);  

        g.setColor(forecolor);  

        g.setFont(new Font("楷体", Font.BOLD, 26));  

        g.drawString(name, 7, height - 8);

        g.setColor(Color.black);  

        float lineWidth = 2.3f;  

        ((Graphics2D)g).setStroke(new BasicStroke(lineWidth)); 

        ((Graphics2D)g).drawOval(2, 2, width-2, height-2);//画一个圆形 
    }
    
    public void setBlank(){
    	setVisible(false);
    }
    
    public int getWidth(){
        return width;
    }
    
    public int getHeight(){
        return height;
    }

    public int getPieceType(){
        return pieceType;
    }

    public int getPlayerType(){
        return playerType;
    }


}