package org.xiangqi.main;

import javax.swing.*;

import java.awt.*;  
import java.awt.event.*;  

public class BlankPiece extends JLabel{
	
	public ChessBoard board;
	
	public int width,height;
	
	public BlankPiece(int width,int height,ChessBoard board){
		
		this.width = width;
		
		this.height = height;
		
		this.board = board;
		
		setSize(width, height); 
		
		board.add(this);
		
		addMouseMotionListener(board);
		
		addMouseListener(board);
		
	}
	
}
