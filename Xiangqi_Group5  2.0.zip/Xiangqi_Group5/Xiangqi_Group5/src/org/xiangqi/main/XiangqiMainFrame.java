package org.xiangqi.main;

import javax.swing.*;

import java.awt.*;  
import java.awt.event.*;  
import java.io.*;  
import java.util.LinkedList; 
import NetSocket.*;

public class XiangqiMainFrame extends JFrame { //主要的执行函数

    private Server server;//服务器包里的类;
   

    //private MenuLoginAndRegister menuLoginAndRegister;

    //private MenuMain menuMain;

    //private MenuServerChoose menuServerChoose;

    private ChessBoard board;

    Container container;
 
    public XiangqiMainFrame(Server server){//再创建的时候加上
    	//构造出整个框架  包括大小
    	
    	this.server = server;
    	
    	initChessBoard();

    	getContentPane().add("Center", board);
    	
    	if(server != null){
    		server.setBoard(board);
    	}

    	setVisible(true);

    	setBounds(60, 20, 470, 520);

    	validate();
    }

    public void initChessBoard(){
    	
    	board = new ChessBoard(45,45,9,10,server);
    	
    }
    
}