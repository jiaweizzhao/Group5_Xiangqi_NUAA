package NetSocket;

import java.io.IOException;  
import java.io.InputStream;  
import java.io.OutputStream;  
import java.net.Socket;  
import java.net.SocketException;  
import java.net.UnknownHostException;

import org.xiangqi.main.ChessBoard;

import java.net.InetAddress;  
  
public class SocketClient extends Thread{  
  
    /** 
     * @param args 
     */
	private Socket clientSocket;
	private String ip;
	InputStream receiveData;
    OutputStream sendData;
    public ChessBoard board = null;
	public SocketClient(String ipAddress,ChessBoard board) {
		clientSocket = null;
		ip = ipAddress;
		receiveData = null;
        sendData = null;
        this.board = board;
	}
	
	public void run() {
		startClient(ip);
	}
	
	public void transferPoint(int chessType,int presentPointX,int presentPointY,int afterPointX,int afterPointY) {
    	String data = Integer.toString(chessType) + " " + Integer.toString(presentPointX) + " " 
    			+ Integer.toString(presentPointY) + " " +Integer.toString(afterPointX) + " " + Integer.toString(afterPointY);
    	try {
			sendData.write(data.getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("66666");
		}
        System.out.println("鎴戠Щ鍔�" + data);
    }
	
    public void startClient(String serverIp) {
    	Socket socket = null;
        //閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹IP閿熸枻鎷峰潃
        //閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鍓跨鍙ｇ尨鎷�
        int port = 999;
        //閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹
        try {
                 //閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹
        		 clientSocket = new Socket(serverIp,port);
                 System.out.println("与服务器建立连接");
                 //閿熸枻鎷峰閿熸枻鎷烽敓鏂ゆ嫹
                 sendData = clientSocket.getOutputStream();
                 receiveData = clientSocket.getInputStream();
                 int n;
                 byte[] b = new byte[1024];
	    	     while(true) {
	    	    	 n = receiveData.read(b);
	    	    	 if(n != 0) {
	    	    		 String rece = new String(b,0,n);
			             String reces[] = rece.split(" ");
			             int chessType = Integer.parseInt(reces[0]);
			             int presentPointX = Integer.parseInt(reces[1]);
			             int presentPointY = Integer.parseInt(reces[2]);
			             int afterPointX = Integer.parseInt(reces[3]);
			             int afterPointY = Integer.parseInt(reces[4]);
			             System.out.println("对方移动");
			             if(board != null) {
					          board.changeConvertPieceToConvertPiece(presentPointX, presentPointY, afterPointX, afterPointY);
					          System.out.println("对方移动了" + rece);
				          }
	    	    	 }
	    	    	 sleep(100);
		             //閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹
		             //閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓锟�
	    	     }
        } catch (Exception e) {
                 e.printStackTrace(); //閿熸枻鎷峰嵃閿熷眾甯搁敓鏂ゆ嫹鎭�
        } finally{
            try {
                //閿熸埅鎲嬫嫹閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹
            	if(socket != null) {
            		sendData.close();
                    receiveData.close();
                    socket.close();
            	} 	
            } catch (Exception e2) {}
        }
    }
}  