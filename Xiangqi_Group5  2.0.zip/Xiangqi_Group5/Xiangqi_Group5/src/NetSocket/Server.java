﻿package NetSocket;

import org.xiangqi.main.*;

public class Server { 
	private static SocketClient client = null;
	private static SocketServer server = null;
	private static UserInfo user = new UserInfo();
	public static ChessBoard board = null;
	
	public void setBoard(ChessBoard board){
		this.board = board;
		if(server != null) {
			server.board = board;
		}
		if(client != null) {
			client.board = board;
		}
	}
	
	public Server() {
		user.start();
	}
	
	public static String setRoom() {
		server = new SocketServer(board);
		server.start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return server.getIp();
	}
	
	public static String getIp() {
		return server.getIp();
	}
	
	public static void jionRoom(String ip) {
		System.out.println("啊哈哈哈");
		client = new SocketClient(ip,board);
		client.start();
	}
	
	public static boolean registerSave(String username,String password) {//////
		return user.registerSave(username,password);
	}
	
	public static boolean loginIfRight(String username,String password) {////////
		return user.loginIfRight(username, password);
	}
	
	
	public static void transferPoint(int chessType,int presentPointX,int presentPointY,int afterPointX,int afterPointY) {
		if(server != null) {
			server.transferPoint(chessType,presentPointX,presentPointY,afterPointX,afterPointY);
		}
		else if(client != null) {
			client.transferPoint(chessType,presentPointX,presentPointY,afterPointX,afterPointY);
		}
	}
}

