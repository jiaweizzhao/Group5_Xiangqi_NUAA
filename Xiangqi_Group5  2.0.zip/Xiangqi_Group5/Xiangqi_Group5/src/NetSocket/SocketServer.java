package NetSocket;

import java.io.IOException;  
import java.io.InputStream;  
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;  
import java.net.Socket;  
import java.net.SocketAddress;
import java.net.UnknownHostException;

import org.xiangqi.main.ChessBoard;
  
public class SocketServer extends Thread{  
  
    //Size of receive buffer  
    private static final int BUFSIZE=32;  
    private ServerSocket serverSocket;
    private Socket clientSocket;
    private InputStream receiveData;
    private OutputStream sendData;
    public ChessBoard board = null;
    /** 
     * @param args 
     */
    private String ip;
    public SocketServer(ChessBoard board) {
    	serverSocket = null;
    	receiveData = null;
    	sendData = null;
    	this.board = board;
    	InetAddress inet;
		try {
			inet = InetAddress.getLocalHost();
			ip = inet.getHostAddress();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    }
    
    public void run() {
    	startServer();
    }
    
    public String getIp() {
    	return ip;
    }
    
    public void transferPoint(int chessType,int presentPointX,int presentPointY,int afterPointX,int afterPointY) {
    	String data = Integer.toString(chessType) + " " + Integer.toString(presentPointX) + " " 
    			+ Integer.toString(presentPointY) + " " +Integer.toString(afterPointX) + " " + Integer.toString(afterPointY);
    	try {
			sendData.write(data.getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.println("我移动了" + data);
    }
    
    public void startServer() {  
        //Test for correct # of args  
    	 System.out.println("服务器开启");
         //閿熸枻鎷烽敓鏂ゆ嫹閿熷壙鍙ｇ尨鎷�
         int port = 1013;
         try {
                  //閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹
                  serverSocket = new ServerSocket(port);
            	  clientSocket = serverSocket.accept();
            	  receiveData = clientSocket.getInputStream();
            	  sendData = clientSocket.getOutputStream();
            	  SocketAddress clientAddress = clientSocket.getRemoteSocketAddress();  
                  System.out.println("与客户端建立联系 "+ clientAddress);  
                  byte[] b = new byte[1024];
                  int n;
                  while(true) {
	                  n = receiveData.read(b);
	                  if(n != 0) {
	                	  String rece = new String(b,0,n);
				          String reces[] = rece.split(" ");
				          int chessType = Integer.parseInt(reces[0]);
				          int presentPointX = Integer.parseInt(reces[1]);
				          int presentPointY = Integer.parseInt(reces[2]);
				          int afterPointX = Integer.parseInt(reces[3]);
				          int afterPointY = Integer.parseInt(reces[4]);
				          if(board != null) {
					          board.changeConvertPieceToConvertPiece(presentPointX, presentPointY, afterPointX, afterPointY);
					          System.out.println("对方移动了" + rece);
				          }
	                  }
	                  sleep(100);
                  }
                  //閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓锟�
         } catch (Exception e) {
                  e.printStackTrace();
                  System.out.println("cuo");
         }
    }
    
    
}